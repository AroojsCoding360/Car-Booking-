import React from 'react';

const Cars = () => {
  const cars = [
    { name: 'Mercedes Grand Sedan', price: 500, image: 'car1.jpg' },
    { name: 'Range Rover', price: 500, image: 'car2.jpg' },
    { name: 'BMW', price: 500, image: 'car3.jpg' },
  ];

  return (
    <div className="container mt-5 pt-5">
      <h2 className="text-center">Choose Your Car</h2>
      <div className="row">
        {cars.map((car, index) => (
          <div key={index} className="col-md-4 mb-4">
            <div className="card">
              <img src={`assets/${car.image}`} className="card-img-top" alt={car.name} />
              <div className="card-body">
                <h5 className="card-title">{car.name}</h5>
                <p className="card-text">${car.price}/day</p>
                <a href="/" className="btn btn-primary">Book now</a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Cars;