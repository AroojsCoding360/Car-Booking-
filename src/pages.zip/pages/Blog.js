import React from 'react';

const Blog = () => {
  const posts = [
    { title: 'Tips for Renting a Car', date: '2024-06-09', image: 'blog1.jpg' },
    { title: 'Top Road Trip Destinations', date: '2024-06-08', image: 'blog2.jpg' },
  ];

  return (
    <div className="container mt-5 pt-5">
      <h2 className="text-center">Recent Blog Posts</h2>
      <div className="row">
        {posts.map((post, index) => (
          <div key={index} className="col-md-6 mb-4">
            <div className="card">
              <img src={`assets/${post.image}`} className="card-img-top" alt={post.title} />
              <div className="card-body">
                <h5 className="card-title">{post.title}</h5>
                <p className="card-text">{post.date}</p>
                <a href="/" className="btn btn-primary">Read more</a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Blog;