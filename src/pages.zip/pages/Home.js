import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="container mt-5 pt-5">
      <div className="jumbotron">
        <h1 className="display-4">Welcome to CARBOOK</h1>
        <p className="lead">Fast & Easy Way To Rent A Car</p>
        <hr className="my-4" />
        <p>Explore our services and find the best car rental options.</p>
        <Link className="btn btn-primary btn-lg mr-2" to="/cars" role="button">View Cars</Link>
        <Link className="btn btn-secondary btn-lg mr-2" to="/pricing" role="button">Pricing</Link>
        <Link className="btn btn-success btn-lg mr-2" to="/services" role="button">Services</Link>
        <Link className="btn btn-info btn-lg" to="/contact" role="button">Contact Us</Link>
      </div>
    </div>
  );
};

export default Home;